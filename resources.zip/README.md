composer require laravel/breeze --dev
php artisan breeze:install react
npm i @fortawesome/fontawesome-free sweetalert2

php artisan make:model Registros -mcr

php artisan make:request Area/StoreRequest
php artisan storage:link